$(function() {

    $(".slide__inner-skrol").onclick({
        window.scrollBy(0, window.innerHeight),
    });
});

// onclick = 'window.scrollBy(0, window.innerHeight)' > window.scrollBy(0, window.innerHeight)